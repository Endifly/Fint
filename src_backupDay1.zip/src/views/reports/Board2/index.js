import React from 'react';
import { Router } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import { AlignCenter } from 'react-feather';

const useStyles = makeStyles(() => ({
    root: {
        fontFamily: "Arial",
        color : "red",
    },
  }));

function Board2() {
    const classes = useStyles();
  return (
    <div>
        <h3 className={classes.root}>noodle</h3>
    </div>
  );
}

export default Board2;
